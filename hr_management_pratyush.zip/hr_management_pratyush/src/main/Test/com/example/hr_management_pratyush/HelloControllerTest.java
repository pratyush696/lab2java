package com.example.hr_management_pratyush;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HelloControllerTest {
    @Test
    void testmyfunction(){

    }


}