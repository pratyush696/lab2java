package com.example.hr_management_pratyush;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;

public class EmployeeController implements Initializable {
    public TableView<Employee> employeeTable;
    public TableColumn<Employee, Integer> employeeid;
    public TableColumn<Employee, String> employeename;
    public TableColumn<Employee, String> employeeemail;
    public TableColumn<Employee, String> employeemobile;
    public TextField employeeIdField;
    public TextField employeeNameField;
    public TextField employeeEmailField;
    public TextField employeeMobileField;

    ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @FXML
    protected void fetchEmployeeData() {
        employeeList.clear();
        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM employee";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int employeeid = resultSet.getInt("employeeid");
                String employeename = resultSet.getString("employeename");
                String employeeemail = resultSet.getString("employeeemail");
                String employeemobile = resultSet.getString("employeemobile");
                employeeTable.getItems().add(new Employee(employeeid, employeename, employeeemail, employeemobile));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        employeeid.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("employeeid"));
        employeename.setCellValueFactory(new PropertyValueFactory<Employee, String>("employeename"));
        employeeemail.setCellValueFactory(new PropertyValueFactory<Employee, String>("employeeemail"));
        employeemobile.setCellValueFactory(new PropertyValueFactory<Employee, String>("employeemobile"));
        employeeTable.setItems(employeeList);
    }

    public void insertEmployeeData(ActionEvent actionEvent) {
        String employeename = employeeNameField.getText();
        String employeeemail = employeeEmailField.getText();
        String employeemobile = employeeMobileField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO `employee` (`employeename`, `employeeemail`, `employeemobile`) VALUES ('" + employeename + "','" + employeeemail + "','" + employeemobile + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateEmployeeData(ActionEvent actionEvent) {
        String employeeid = employeeIdField.getText();
        String employeename = employeeNameField.getText();
        String employeeemail = employeeEmailField.getText();
        String employeemobile = employeeMobileField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE `employee` SET `employeename`='" + employeename + "',`employeeemail`='" + employeeemail + "',`employeemobile`='" + employeemobile + "' WHERE employeeid='" + employeeid + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteEmployeeData(ActionEvent actionEvent) {
        String employeeid = employeeIdField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM `employee` WHERE employeeid='" + employeeid + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadEmployeeData(ActionEvent actionEvent) {
        String employeeid = employeeIdField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM employee WHERE employeeid='" + employeeid + "'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String employeename = resultSet.getString("employeename");
                String employeeemail = resultSet.getString("employeeemail");
                String employeemobile = resultSet.getString("employeemobile");

                employeeNameField.setText(employeename);
                employeeEmailField.setText(employeeemail);
                employeeMobileField.setText(employeemobile);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

