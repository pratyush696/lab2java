package com.example.hr_management_pratyush;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;

public class AdminController implements Initializable {
    public TableView<Admin> adminTable;
    public TableColumn<Admin,Integer> adminid;
    public TableColumn<Admin,String> adminname;
    public TableColumn<Admin,String> adminemail;
    public TableColumn<Admin,String> adminpassword;
    public TextField adminIdField;
    public TextField adminNameField;
    public TextField adminEmailField;
    public TextField adminPasswordField;

    ObservableList<Admin> adminList = FXCollections.observableArrayList();

    @FXML
    protected void fetchAdminData() {
        adminList.clear();
        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM admin";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int adminid = resultSet.getInt("adminid");
                String adminname = resultSet.getString("adminname");
                String adminemail = resultSet.getString("adminemail");
                String adminpassword = resultSet.getString("adminpassword");
                adminTable.getItems().add(new Admin(adminid, adminname, adminemail, adminpassword));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        adminid.setCellValueFactory(new PropertyValueFactory<Admin,Integer>("adminid"));
        adminname.setCellValueFactory(new PropertyValueFactory<Admin,String>("adminname"));
        adminemail.setCellValueFactory(new PropertyValueFactory<Admin,String>("adminemail"));
        adminpassword.setCellValueFactory(new PropertyValueFactory<Admin,String>("adminpassword"));
        adminTable.setItems(adminList);
    }

    public void insertAdminData(ActionEvent actionEvent) {
        String adminname = adminNameField.getText();
        String adminemail = adminEmailField.getText();
        String adminpassword = adminPasswordField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO `admin` (`adminname`, `adminemail`, `adminpassword`) VALUES ('" + adminname + "','" + adminemail + "','" + adminpassword + "')";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAdminData(ActionEvent actionEvent) {
        String adminid = adminIdField.getText();
        String adminname = adminNameField.getText();
        String adminemail = adminEmailField.getText();
        String adminpassword = adminPasswordField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE `admin` SET `adminname`='" + adminname + "',`adminemail`='" + adminemail + "',`adminpassword`='" + adminpassword + "' WHERE adminid='" + adminid + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAdminData(ActionEvent actionEvent) {
        String adminid = adminIdField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM `admin` WHERE adminid='" + adminid + "'";
            Statement statement = connection.createStatement();
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadAdminData(ActionEvent actionEvent) {
        String adminid = adminIdField.getText();

        String jdbcUrl = "jdbc:mysql://localhost:3306/admin";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM admin WHERE adminid='" + adminid + "'";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String adminname = resultSet.getString("adminname");
                String adminemail = resultSet.getString("adminemail");
                String adminpassword = resultSet.getString("adminpassword");

                adminNameField.setText(adminname);
                adminEmailField.setText(adminemail);
                adminPasswordField.setText(adminpassword);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
