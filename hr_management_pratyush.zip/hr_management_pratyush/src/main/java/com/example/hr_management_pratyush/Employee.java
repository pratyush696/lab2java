package com.example.hr_management_pratyush;

public class Employee {
    private int employeeid;
    private String employeename;
    private String employeeemail;
    private String employeemobile;

    public Employee(int employeeid, String employeename, String employeeemail, String employeemobile) {
        this.employeeid = employeeid;
        this.employeename = employeename;
        this.employeeemail = employeeemail;
        this.employeemobile = employeemobile;
    }

    public int getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(int employeeid) {
        this.employeeid = employeeid;
    }

    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getEmployeeemail() {
        return employeeemail;
    }

    public void setEmployeeemail(String employeeemail) {
        this.employeeemail = employeeemail;
    }

    public String getEmployeemobile() {
        return employeemobile;
    }

    public void setEmployeemobile(String employeemobile) {
        this.employeemobile = employeemobile;
    }
}
